//codes modified from inclass example file sktech9.js, created by Katlin


// Codes from example of sketch9 inclass start
let video
let skeleton
let pose
let angle=0
let history = [];
// Codes from example of sketch9 inclass start

let noseX
let noseY
let leftWristX
let leftWristY
let rightWristX
let rightWristY

let drum
let drum2
let guitar
let bass

function preload(){
    drum = loadSound('drum.wav')
    drum2 = loadSound('drum2.wav')
    guitar = loadSound('guitar.wav')
    bass = loadSound('bass&pad.wav')
}

function setup() {
// Codes from example of sketch9 inclass start
  createCanvas(600, 500);
  noStroke();
  video = createCapture(VIDEO)
  video.size(width,height)
    
    
  video.hide()
  
  poseNet = ml5.poseNet(video,modelLoaded)
  poseNet.on("pose",gotPoses)
    
    rectMode(CENTER);
    angleMode(DEGREES);
// Codes from example of sketch9 inclass end

}

function modelLoaded(){
    console.log("modelLoaded function has been called so this work!!!");
};



function gotPoses(poses){
  //console.log(poses)
    //Codes from example of sketch9 inclass start
    if( poses.length > 0 ){
        pose = poses[0].pose;
        skeleton = poses[0].skeleton; 
    } 
    //Codes from example of sketch9 inclass end
    
    
    
  noseX = poses[0].pose.nose.x
  noseY = poses[0].pose.nose.y
    
  leftWristX = poses[0].pose.leftWrist.x
  leftWristY = poses[0].pose.leftWrist.y
  rightWristX = poses[0].pose.rightWrist.x
  rightWristY = poses[0].pose.rightWrist.y
    
  //console.log(noseX)
  console.log(noseX,leftWristY,rightWristY)
}




function draw() {
 // background(220);
//  image(video,0,0,600,500)
//  fill(255,0,0)
//  ellipse(noseX,noseY,40)
    
    
    
// Codes from example of sketch9 inclass start
image(video, 0, 0,width,height);
//TRESHOLD 0 is white - 1 is black
filter(THRESHOLD,1);    

    
    if(pose){
        //noStroke();
    noFill();    
    stroke(255,0,0);
    

        
        
    let d = dist(pose.leftEye.x,pose.leftEye.y, pose.rightEye.x,pose.rightEye.y);
        
    ellipse(pose.nose.x, pose.nose.y, d*3);
    
        let v = createVector(pose.nose.x,pose.nose.y);
        
        history.push(v);
        //console.log("history.length " + history.length);
        let head = history[history.length-1].copy();
        history.push(head);
        //console.log("head " + );
        //head.x += pose.nose.x;
        //head.y += pose.nose.y;
        history.shift();
        
        //if(history.length > 50){
        
        for(let i = 0; i < history.length-1; i++){
            //console.log("history[i].y " + history[i].y);
            //ellipse(history[i].x, history[i].y, d*3);
            //console.log("i");
            drawHeadSpace(history[i].x,history[i].y);
            
        }
        
    for(let i=0; i < pose.keypoints.length;i++){
    //for(let i=0; i < 5;i++){
    let x = pose.keypoints[i].position.x;
    let y = pose.keypoints[i].position.y;
    
    
    rect(x,y,25,25);
    
    for(let i = 0; i < skeleton.length; i++){
        let a = skeleton[i][0];
        let b = skeleton[i][1];
        strokeWeight(2);
        stroke(255);
        line(a.position.x, a.position.y,b.position.x, b.position.y );
        fill(127);
        //rect((a.position.x)/2, (a.position.y)/2,(b.position.x)/2, (b.position.y)/2 );
         //rect(a.position.x,b.position.y,10,10);
        }    
    }
}
// Codes from example of sketch9 inclass end
    
    
  if(noseX < 200){
    if(!drum.isPlaying()){
       drum.play()
    }
  }
    
  if(noseX > 400){
    if(!drum2.isPlaying()){
       drum2.play()
    }
  }
    
   
  stroke(255,255,255)
  ellipse(leftWristX,leftWristY,40)
  ellipse(rightWristX,rightWristY,40) 
    
    if(leftWristY < 150){
    if(!guitar.isPlaying()){
      guitar.play()
    }
  }
    
    if(rightWristY < 150){
    if(!bass.isPlaying()){
      bass.play()
    }
  }
  
}


////Codes from example of sketch9 inclass start
function drawHeadSpace(x,y){
        
    fill(190, 52, 240, 80);
        ellipse(x, y,100);
        //console.log("drawHeadSpace " + x);
        //history.splice(0,1); 
    if(history.length > 20){
        console.log("more than 20");
        history.splice(0,1);
        }
    }
//Codes from example of sketch9 inclass end