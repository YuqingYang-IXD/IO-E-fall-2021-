/* 
August 2019 - Doug Whitton 
play 3 analog sensors that output sound and circle graphic
The Arduino file that's running is "threeSensorExample"

edited by Yuqing Yang
November 28, 2021
*/

let osc;
let playing = false;
let serial;
let latestData = "waiting for data";  // you'll use this to write incoming data to the canvas
let splitter;
//let diameter0 = 0, diameter1 = 0, diameter2 = 0;
let diameter1 = 0;
//let osc1, osc2, osc3, fft;
let osc1, fft;


function setup() {
  
  createCanvas(windowWidth, windowHeight);

///////////////////////////////////////////////////////////////////
    //Begin serialport library methods, this is using callbacks
///////////////////////////////////////////////////////////////////    
    

  // Instantiate our SerialPort object
  serial = new p5.SerialPort();

  // Get a list the ports available
  // You should have a callback defined to see the results
  serial.list();
  console.log("serial.list()   ", serial.list());

  //////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////
  // Assuming our Arduino is connected, let's open the connection to it
  // Change this to the name of your arduino's serial port
  serial.open("/dev/tty.SLAB_USBtoUART");
 /////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////
  // Here are the callbacks that you can register

  // When we connect to the underlying server
  serial.on('connected', serverConnected);

  // When we get a list of serial ports that are available
  serial.on('list', gotList);
  // OR
  //serial.onList(gotList);

  // When we some data from the serial port
  serial.on('data', gotData);
  // OR
  //serial.onData(gotData);

  // When or if we get an error
  serial.on('error', gotError);
  // OR
  //serial.onError(gotError);

  // When our serial port is opened and ready for read/write
  serial.on('open', gotOpen);
  // OR
  //serial.onOpen(gotOpen);

  // Callback to get the raw data, as it comes in for handling yourself
  //serial.on('rawdata', gotRawData);
  // OR
  //serial.onRawData(gotRawData);

 
}
////////////////////////////////////////////////////////////////////////////
// End serialport callbacks
///////////////////////////////////////////////////////////////////////////


osc1 = new p5.TriOsc(); // set frequency and type
osc1.amp(.5);
/*
osc2 = new p5.TriOsc(); // set frequency and type
osc2.amp(.5);  
osc3 = new p5.TriOsc(); // set frequency and type
osc3.amp(.5);  
*/

fft = new p5.FFT();
osc1.start();
//osc2.start(); 
//osc3.start();

// We are connected and ready to go
function serverConnected() {
  console.log("Connected to Server");
}

// Got the list of ports
function gotList(thelist) {
  console.log("List of Serial Ports:");
  // theList is an array of their names
  for (var i = 0; i < thelist.length; i++) {
    // Display in the console
    console.log(i + " " + thelist[i]);
  }
}

// Connected to our serial device
function gotOpen() {
  console.log("Serial Port is Open");
}

// Ut oh, here is an error, let's log it
function gotError(theerror) {
  console.log(theerror);
}



// There is data available to work with from the serial port
function gotData() {
  var currentString = serial.readLine();  // read the incoming string
  trim(currentString);                    // remove any trailing whitespace
  if (!currentString) return;             // if the string is empty, do no more
  console.log("currentString  ", currentString);             // println the string
  latestData = currentString;            // save it for the draw method
  console.log("latestData" + latestData);   //check to see if data is coming in
  splitter = split(latestData, ',');       // split each number using the comma as a delimiter
  //console.log("splitter[0]" + splitter[0]); 
  diameter0 = splitter[0];                 //put the first sensor's data into a variable
  diameter1 = splitter[1];
  diameter2 = splitter[2]; 



}

// We got raw data from the serial port
function gotRawData(thedata) {
  println("gotRawData" + thedata);
}

// Methods available
// serial.read() returns a single byte of data (first in the buffer)
// serial.readChar() returns a single char 'A', 'a'
// serial.readBytes() returns all of the data available as an array of bytes
// serial.readBytesUntil('\n') returns all of the data available until a '\n' (line break) is encountered
// serial.readString() retunrs all of the data available as a string
// serial.readStringUntil('\n') returns all of the data available as a string until a specific string is encountered
// serial.readLine() calls readStringUntil with "\r\n" typical linebreak carriage return combination
// serial.last() returns the last byte of data from the buffer
// serial.lastChar() returns the last byte of data from the buffer as a char
// serial.clear() clears the underlying serial buffer
// serial.available() returns the number of bytes available in the buffer
// serial.write(somevar) writes out the value of somevar to the serial device


function draw() {
  noStroke();
  //background(151, 172, 190);
  text(latestData, 10,10);
  /*
    //ellipse controlled by button
    ellipseMode(RADIUS);    
    fill(255,255,255);
    noStroke(); 
    //console.log("diameter0  "  + diameter0);
    ellipse(mouseX,mouseY, diameter0*100, diameter0*100);
*/
   
    //ellipse controlled by potentialmeter
    ellipseMode(RADIUS);    
    fill(60, 102, 137);
    ellipse(500, 0, diameter1*2.0, diameter1*2.0);
    
    ellipseMode(RADIUS);    
    fill(151, 172, 190);
    ellipse(500, 0, diameter1*1.8, diameter1*1.8);
    
    ellipseMode(RADIUS);    
    fill(60, 102, 137);
    ellipse(500, 0, diameter1*1.5, diameter1*1.5);
    
    ellipseMode(RADIUS);    
    fill(151, 172, 190);
    ellipse(500, 0, diameter1*1.3, diameter1*1.3);
    
    ellipseMode(RADIUS);    
    fill(60, 102, 137);
    ellipse(500, 0, diameter1, diameter1);
    
    ellipseMode(RADIUS);    
    fill(151, 172, 190);
    ellipse(500, 0, diameter1*0.8, diameter1*0.8);
    
    ellipseMode(RADIUS);    
    fill(60, 102, 137);
    ellipse(500, 0, diameter1*0.5, diameter1*0.5);
    
    ellipseMode(RADIUS);    
    fill(151, 172, 190);
    ellipse(500, 0, diameter1*0.3, diameter1*0.3);
    
    ellipseMode(RADIUS);    
    fill(60, 102, 137);
    ellipse(500, 0, diameter1*0.1, diameter1*0.1);
        
    
/*
    //press the spacekey to control playing the drum sound effect
    var drum = document.getElementById('drum');
    document.body.onkeyup = function(e){
        var event = e || window.event;
    console.log('keyCode : ' + event.keyCode);
    if(!arguments.callee.pause){
        arguments.callee.pause = false;
    }
    if(event.keyCode == 32){
        if(!arguments.callee.pause){
            arguments.callee.pause = true;
            audio.pause();
        }else{
            arguments.callee.pause = false;
            drum.play();
        }
    }
    }
*/
    
    //codes start reference from https://www.codercto.com/a/51654.html
    var sounds = {
        32 : 'wave', // space key
     }; 
    document.onkeydown = function(e) { 
        var soundId = sounds[e.keyCode]; 
        if (soundId) document.getElementById(soundId).play(); 
        else console.log("key not mapped : code is", e.keyCode); 
    }
    //codes end reference from https://www.codercto.com/a/51654.html
                  
  
  var freq = map(diameter1, 0, width, 40, 880);    
    osc1.freq(freq);
    //console.log(freq);

}


function mouseClicked(){
  if (getAudioContext().state !== 'running') {
    getAudioContext().resume();
    console.log("getAudioContext().state" + getAudioContext().state);
  }
  };


/* auto play the audio file
var audio;
     function voicePlay () {
         audio = "river.wav";
         audio = new Audio(audio); 
         // loop
         $(audio).unbind("ended").bind("ended", function(){
               audio.play();
         })
         audio.play();
     }
     function voiceClose () {
         audio.pause();
     }
*/

 