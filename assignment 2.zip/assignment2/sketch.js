let video
let noseX
let noseY
let leftWristX
let leftWristY


let drum
let guitar

function preload(){
    drum = loadSound('drum.wav')
    guitar = loadSound('guitar.wav')
}

function setup() {
  createCanvas(600, 500);
  video = createCapture(VIDEO)
  video.size(600,500)
  video.hide()
  
  let poseFinder = ml5.poseNet(video)
  poseFinder.on("pose",gotPose)
}

function draw() {
  background(220);
  image(video,0,0,600,500)
  fill(255,0,0)
  ellipse(noseX,noseY,40)
  if(noseX < 200){
    if(!drum.isPlaying()){
       drum.play()
    }
  }
    
   
  fill(0,0,0)
  ellipse(leftWristX,leftWristY,40)
    if(leftWristY > 250){
    if(!guitar.isPlaying()){
      guitar.play()
    }
  }
  
}


function gotPose(poses){
  //console.log(poses)
  noseX = poses[0].pose.nose.x
  noseY = poses[0].pose.nose.y
    
  leftWristX = poses[0].pose.leftWrist.x
  leftWristY = poses[0].pose.leftWrist.y
    
  console.log(noseX)
    //console.log(noseX,leftWristY)
}




